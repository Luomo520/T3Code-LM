package com.swmansion.enriched.markdown.styles

internal data class TextHighlightStyle(
  val pattern: Regex,
  val inlineCodeEdge: Regex,
  val colors: List<Int?>,
)
